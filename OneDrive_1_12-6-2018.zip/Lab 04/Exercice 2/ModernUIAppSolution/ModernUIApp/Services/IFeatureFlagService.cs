namespace ModernUIApp.Services {
    public interface IFeatureFlagService {
        bool ViewFeature (string Username);
    }
}