dotnet test ./ModernApiAppSolution/ModernApiApp.Tests/ModernApiApp.Tests.csproj /p:AltCover=true
dotnet test ./ModernUIAppSolution/ModernUIApp.Tests/ModernUIApp.Tests.csproj /p:AltCover=true
